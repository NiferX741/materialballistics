package com.niferx.materialballistics.ballistics;

import com.niferx.materialballistics.config.LoadedConfig;
import com.niferx.materialballistics.config.SurfaceRule;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Choisit une surface. Les tags du JSON passent avant l'heuristique, dans l'ordre du fichier.
 * <p>
 * {@code BlockState#getSoundType()} est la méthode vanilla. NeoForge la marque dépréciée
 * au profit d'une surcharge avec position et entité, qui n'existe pas sur Fabric.
 * <p>
 * La normale disponible ici est la face du bloc ({@code Direction}), pas la pente visuelle
 * d'un escalier ou d'une dalle. Un hit sur la marche d'un escalier reste axis-aligné.
 */
public final class SurfaceClassifier {
    private SurfaceClassifier() {
    }

    @SuppressWarnings("deprecation")
    public static ResolvedSurface classify(BlockState state, BlockGetter level, BlockPos pos, LoadedConfig config) {
        for (SurfaceRule rule : config.rules()) {
            if (state.is(rule.tag())) {
                return rule.resolve();
            }
        }

        if (isOpenFluid(state, level, pos)) {
            return new ResolvedSurface(
                    SurfaceBehavior.SLOW,
                    config.fluidRestitution(),
                    config.fluidFriction(),
                    config.fluidMaxBounces(),
                    SurfaceTone.WET
            );
        }

        SoundType sound = state.getSoundType();
        float hardness = state.getDestroySpeed(level, pos);
        if (sound == SoundType.SNOW || sound == SoundType.POWDER_SNOW || sound == SoundType.SOUL_SAND || sound == SoundType.SOUL_SOIL) {
            return new ResolvedSurface(SurfaceBehavior.SLIDE, 0.2, 0.94, 4, SurfaceTone.DULL);
        }
        // Bois, terre, laine : la dureté du bois dépasse 1,5, il ne faut pas le traiter comme de la pierre.
        if (isSoftSound(sound)) {
            return ResolvedSurface.stick(SurfaceTone.DULL);
        }
        // Le verre est mou (dureté ~0,3) mais doit rebondir : le tester avant le seuil « tendre ».
        if (sound == SoundType.GLASS) {
            return new ResolvedSurface(
                    SurfaceBehavior.RICOCHET,
                    config.glassRestitution(),
                    config.glassFriction(),
                    config.fallbackMaxBounces(),
                    SurfaceTone.GLASS
            );
        }
        if (isHardSound(sound) || hardness < 0.0F || hardness >= config.fallbackHardness()) {
            SurfaceTone tone = isMetalSound(sound) ? SurfaceTone.METAL : SurfaceTone.MINERAL;
            return new ResolvedSurface(
                    SurfaceBehavior.RICOCHET,
                    config.fallbackRestitution(),
                    config.fallbackFriction(),
                    config.fallbackMaxBounces(),
                    tone
            );
        }
        return ResolvedSurface.stick(SurfaceTone.DULL);
    }

    private static boolean isOpenFluid(BlockState state, BlockGetter level, BlockPos pos) {
        return !state.getFluidState().isEmpty() && state.getCollisionShape(level, pos).isEmpty();
    }

    private static boolean isSoftSound(SoundType sound) {
        return sound == SoundType.WOOD
                || sound == SoundType.GRASS
                || sound == SoundType.SAND
                || sound == SoundType.GRAVEL
                || sound == SoundType.WOOL
                || sound == SoundType.MUD
                || sound == SoundType.ROOTED_DIRT
                || sound == SoundType.MOSS
                || sound == SoundType.WET_GRASS;
    }

    private static boolean isHardSound(SoundType sound) {
        return sound == SoundType.STONE
                || sound == SoundType.DEEPSLATE
                || sound == SoundType.TUFF
                || sound == SoundType.CALCITE
                || sound == SoundType.AMETHYST
                || sound == SoundType.BASALT
                || sound == SoundType.NETHERRACK
                || sound == SoundType.DRIPSTONE_BLOCK
                || sound == SoundType.POINTED_DRIPSTONE
                || isMetalSound(sound);
    }

    private static boolean isMetalSound(SoundType sound) {
        return sound == SoundType.METAL
                || sound == SoundType.IRON
                || sound == SoundType.ANVIL
                || sound == SoundType.COPPER
                || sound == SoundType.COPPER_BULB
                || sound == SoundType.COPPER_GRATE
                || sound == SoundType.NETHERITE_BLOCK
                || sound == SoundType.HEAVY_CORE;
    }
}
