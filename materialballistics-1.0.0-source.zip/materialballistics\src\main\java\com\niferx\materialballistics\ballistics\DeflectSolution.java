package com.niferx.materialballistics.ballistics;

import net.minecraft.world.phys.Vec3;

/**
 * Résultat pur du calcul. {@code apply == false} signifie « laisser le plantage vanilla ».
 *
 * @param countBounce      vrai seulement pour un ricochet qui consomme un rebond
 * @param damageMultiplier facteur appliqué aux dégâts de flèche après cet impact
 */
public record DeflectSolution(
        boolean apply,
        boolean countBounce,
        Vec3 velocity,
        Vec3 position,
        double damageMultiplier,
        SurfaceBehavior behavior,
        SurfaceTone tone
) {
    public static DeflectSolution stick() {
        return new DeflectSolution(false, false, Vec3.ZERO, Vec3.ZERO, 1.0, SurfaceBehavior.STICK, SurfaceTone.DULL);
    }
}
