package com.niferx.materialballistics;

import com.niferx.materialballistics.ballistics.BallisticAttachments;
import com.niferx.materialballistics.config.BallisticsConfig;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Balistique à matériaux pour Minecraft 26.3 / Fabric.
 * <p>
 * Le jeu est livré non obfusqué depuis 26.1 : ce mod est écrit en mappings Mojang
 * ({@code AbstractArrow}, {@code Vec3}, {@code BlockHitResult#getDirection()}).
 * Les noms Yarn ({@code PersistentProjectileEntity}, {@code Vec3d}, {@code getSide()})
 * ne sont plus le contrat du template Fabric.
 */
public final class MaterialBallistics implements ModInitializer {
    public static final String MOD_ID = "materialballistics";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        // Charge la classe pour enregistrer l'attachment avant le premier projectile.
        BallisticAttachments.init();
        BallisticsConfig.load();
        ServerLifecycleEvents.SERVER_STARTED.register(server -> BallisticsConfig.load());
        LOGGER.info("Material Ballistics prêt (ricochets par tag de blocs).");
    }

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }
}
