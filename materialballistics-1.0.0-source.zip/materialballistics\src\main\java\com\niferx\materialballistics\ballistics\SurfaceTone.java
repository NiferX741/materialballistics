package com.niferx.materialballistics.ballistics;

/**
 * Famille sonore utilisée par le retour d'impact. Elle ne décide pas le rebond.
 */
public enum SurfaceTone {
    MINERAL,
    METAL,
    GLASS,
    DULL,
    WET
}
