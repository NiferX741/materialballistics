package com.niferx.materialballistics.config;

import com.niferx.materialballistics.ballistics.ResolvedSurface;
import com.niferx.materialballistics.ballistics.SurfaceBehavior;
import com.niferx.materialballistics.ballistics.SurfaceTone;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;

/**
 * Première règle dont le tag contient le bloc l'emporte. L'ordre du JSON est donc la priorité.
 */
public record SurfaceRule(
        TagKey<Block> tag,
        SurfaceBehavior behavior,
        double normalRestitution,
        double tangentialFriction,
        int maxBounces,
        SurfaceTone tone
) {
    public ResolvedSurface resolve() {
        return new ResolvedSurface(behavior, normalRestitution, tangentialFriction, maxBounces, tone);
    }
}
