package com.niferx.materialballistics.ballistics;

import com.niferx.materialballistics.config.BallisticsConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Les flèches vanilla raycastent sans les fluides, donc elles traversent l'eau.
 * Avant le mouvement du tick, on cherche la surface et on ricoche si le projectile
 * arrive depuis l'extérieur. Déjà immergé, il garde la traînée vanilla.
 */
public final class FluidRicochet {
    private FluidRicochet() {
    }

    public static boolean trySkip(AbstractArrow arrow) {
        if (!BallisticsConfig.get().enabled()) {
            return false;
        }
        if (arrow.isRemoved() || arrow.isNoPhysics()) {
            return false;
        }
        Level level = arrow.level();
        Vec3 start = arrow.position();
        if (isSubmerged(level, arrow, start)) {
            return false;
        }
        Vec3 velocity = arrow.getDeltaMovement();
        if (velocity.lengthSqr() < 1.0E-6) {
            return false;
        }
        BlockHitResult hit = level.clip(new ClipContext(
                start,
                start.add(velocity),
                ClipContext.Block.COLLIDER,
                ClipContext.Fluid.ANY,
                arrow
        ));
        if (hit.getType() != HitResult.Type.BLOCK || hit.isInside() || hit.isWorldBorderHit()) {
            return false;
        }
        BlockPos pos = hit.getBlockPos();
        BlockState state = level.getBlockState(pos);
        FluidState fluid = state.getFluidState();
        // Un bloc solide, même waterlogged, reste géré par le ricochet de bloc.
        if (fluid.isEmpty() || !state.getCollisionShape(level, pos).isEmpty()) {
            return false;
        }
        return RicochetController.tryDeflect(arrow, hit, false);
    }

    private static boolean isSubmerged(Level level, AbstractArrow arrow, Vec3 position) {
        BlockPos pos = arrow.blockPosition();
        FluidState fluid = level.getFluidState(pos);
        if (fluid.isEmpty()) {
            return false;
        }
        double surface = pos.getY() + fluid.getHeight(level, pos);
        return position.y < surface - 0.05;
    }
}
