package com.niferx.materialballistics.mixin;

import com.niferx.materialballistics.ballistics.FluidRicochet;
import com.niferx.materialballistics.ballistics.RicochetController;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Branche les flèches vanilla. {@code onHitBlock} est protected sur
 * {@code AbstractArrow} et c'est lui qui pose {@code inGround}, joue le son
 * de plantage et écrase la vélocité. On l'annule seulement quand le contrôleur
 * a déjà posé une vitesse sortante.
 * <p>
 * {@code tick} se termine par une réaffirmation : {@code stepMoveAndHit} peut
 * encore déplacer la flèche après le callback. {@code onHitEntity} filtre le
 * doublon de dégâts sur la cible que le rebond vient de quitter.
 */
@Mixin(AbstractArrow.class)
public abstract class AbstractArrowRicochetMixin {
    @Shadow
    protected int inGroundTime;

    @Shadow
    protected abstract boolean isInGround();

    @Shadow
    protected abstract void setInGround(boolean inGround);

    @Inject(method = "tick", at = @At("HEAD"))
    private void materialballistics$fluidSurface(CallbackInfo ci) {
        AbstractArrow arrow = (AbstractArrow) (Object) this;
        if (!isInGround() && FluidRicochet.trySkip(arrow)) {
            aimAlongVelocity(arrow);
        }
    }

    @Inject(method = "onHitBlock", at = @At("HEAD"), cancellable = true)
    private void materialballistics$ricochet(BlockHitResult hit, CallbackInfo ci) {
        AbstractArrow arrow = (AbstractArrow) (Object) this;
        if (RicochetController.tryDeflect(arrow, hit)) {
            setInGround(false);
            this.inGroundTime = 0;
            arrow.shakeTime = 4;
            arrow.setCritArrow(false);
            // updateRotation() est sur Projectile, pas sur AbstractArrow : un @Shadow ici ne le trouve pas.
            aimAlongVelocity(arrow);
            ci.cancel();
        }
    }

    private static void aimAlongVelocity(AbstractArrow arrow) {
        Vec3 velocity = arrow.getDeltaMovement();
        double horizontal = velocity.horizontalDistance();
        arrow.setYRot((float) Math.toDegrees(Math.atan2(velocity.x, velocity.z)));
        arrow.setXRot((float) Math.toDegrees(Math.atan2(velocity.y, horizontal)));
        arrow.yRotO = arrow.getYRot();
        arrow.xRotO = arrow.getXRot();
    }

    @Inject(method = "tick", at = @At("RETURN"))
    private void materialballistics$reassert(CallbackInfo ci) {
        if (RicochetController.reassert((Projectile) (Object) this)) {
            setInGround(false);
            this.inGroundTime = 0;
        }
    }

    @Inject(method = "onHitEntity", at = @At("HEAD"), cancellable = true)
    private void materialballistics$suppressDuplicate(EntityHitResult hit, CallbackInfo ci) {
        if (RicochetController.shouldSuppressEntityHit((Projectile) (Object) this, hit.getEntity())) {
            ci.cancel();
        }
    }

    @Inject(method = "onHitEntity", at = @At("RETURN"))
    private void materialballistics$rememberHit(EntityHitResult hit, CallbackInfo ci) {
        RicochetController.rememberEntityHit((Projectile) (Object) this, hit.getEntity());
    }
}
