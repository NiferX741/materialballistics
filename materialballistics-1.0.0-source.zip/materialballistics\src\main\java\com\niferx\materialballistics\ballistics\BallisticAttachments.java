package com.niferx.materialballistics.ballistics;

import com.niferx.materialballistics.MaterialBallistics;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;

/**
 * Donnée accrochée à l'entité. L'API d'attachment Fabric est encore marquée instable,
 * mais c'est le canal prévu pour un état qui doit survivre à la sauvegarde et au client.
 */
@SuppressWarnings("UnstableApiUsage")
public final class BallisticAttachments {
    public static final AttachmentType<BallisticMemory> MEMORY = AttachmentRegistry.create(
            MaterialBallistics.id("memory"),
            builder -> builder
                    .initializer(BallisticMemory::new)
                    .persistent(BallisticMemory.CODEC)
                    .syncWith(BallisticMemory.STREAM_CODEC, AttachmentSyncPredicate.all())
    );

    private BallisticAttachments() {
    }

    public static void init() {
        // Référence statique : le registre n'existe que si cette classe est chargée.
    }
}
