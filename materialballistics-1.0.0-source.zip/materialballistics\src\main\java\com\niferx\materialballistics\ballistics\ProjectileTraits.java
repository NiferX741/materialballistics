package com.niferx.materialballistics.ballistics;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Plafond de rebonds propre au type de projectile. Il se combine au plafond de la surface
 * par un minimum : une flèche suit la règle de bloc, un objet lancé peut être bridé plus bas.
 */
public record ProjectileTraits(int bounceCap, boolean scaleArrowDamage) {
    public static final ProjectileTraits ARROW = new ProjectileTraits(Integer.MAX_VALUE, true);
    /** Un objet lancé ne ricoche qu'une fois, et n'a pas de {@code baseDamage} de flèche. */
    public static final ProjectileTraits THROWN = new ProjectileTraits(1, false);
    public static final ProjectileTraits GENERIC = new ProjectileTraits(2, false);

    private static final Map<EntityType<?>, ProjectileTraits> BY_TYPE = new ConcurrentHashMap<>();

    public static void register(EntityType<? extends Projectile> type, ProjectileTraits traits) {
        BY_TYPE.put(type, traits);
    }

    public static ProjectileTraits of(Projectile projectile) {
        ProjectileTraits registered = BY_TYPE.get(projectile.getType());
        if (registered != null) {
            return registered;
        }
        if (projectile instanceof AbstractArrow) {
            return ARROW;
        }
        return GENERIC;
    }
}
