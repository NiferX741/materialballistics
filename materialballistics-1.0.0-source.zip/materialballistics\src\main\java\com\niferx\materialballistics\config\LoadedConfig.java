package com.niferx.materialballistics.config;

import java.util.List;

/**
 * Copie figée lue par les impacts. Rechargée au démarrage du serveur, pas à chaque flèche.
 */
public record LoadedConfig(
        boolean enabled,
        double minSpeed,
        double separation,
        double skimAlignment,
        double sweetSpotAlignment,
        double headOnDamageMultiplier,
        double sweetSpotDamageMultiplier,
        double damageCap,
        int sameEntityImmunityTicks,
        double sameEntityRearmDistance,
        int slowRepeatWindow,
        double glassRestitution,
        double glassFriction,
        double fallbackHardness,
        double fallbackSlowKeep,
        double fallbackRestitution,
        double fallbackFriction,
        int fallbackMaxBounces,
        double fluidRestitution,
        double fluidFriction,
        int fluidMaxBounces,
        double fluidSeparation,
        List<SurfaceRule> rules
) {
}
