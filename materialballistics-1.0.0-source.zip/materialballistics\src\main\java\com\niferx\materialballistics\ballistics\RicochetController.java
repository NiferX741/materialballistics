package com.niferx.materialballistics.ballistics;

import com.niferx.materialballistics.config.BallisticsConfig;
import com.niferx.materialballistics.config.LoadedConfig;
import com.niferx.materialballistics.mixin.AbstractArrowAccessor;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Point d'entrée unique du ricochet.
 * <p>
 * Déjà branché sur {@code AbstractArrow} (flèche, flèche spectrale, trident)
 * par {@code AbstractArrowRicochetMixin}. Une sous-classe qui réécrit
 * {@code onHitBlock} sans appeler {@code super} doit appeler {@link #tryDeflect}
 * elle-même et, si le résultat est vrai, ne pas planter le projectile.
 * <p>
 * Les objets lancés ({@code Snowball}, œuf, potion, perle) ne s'arrêtent pas
 * dans {@code onHitBlock} : leur {@code onHit} appelle {@code discard()} après
 * {@code super}. Annuler seulement le plantage ne suffit pas. Il faut un mixin
 * sur chaque {@code onHit}, appeler {@code tryDeflect} quand le résultat est un
 * {@code BlockHitResult}, et ne pas jeter l'entité si la déflexion a réussi.
 * Enregistrer le type avec {@link ProjectileTraits#register} et le trait
 * {@link ProjectileTraits#THROWN} pour plafonner à un rebond.
 * <p>
 * Les boules de feu, charges de vent et balles de shulker ne passent pas par ce
 * contrôleur. Leur {@code onHitBlock} a un effet propre (explosion, impulsion).
 */
public final class RicochetController {
    private RicochetController() {
    }

    /**
     * @return vrai si le plantage vanilla doit être annulé
     */
    public static boolean tryDeflect(Projectile projectile, BlockHitResult hit) {
        return tryDeflect(projectile, hit, true);
    }

    /**
     * @param reassertAtTickEnd faux pour un ricochet posé en début de tick (fluide) :
     *                          la fin de tick ne doit pas ramener le projectile au point de contact
     */
    public static boolean tryDeflect(Projectile projectile, BlockHitResult hit, boolean reassertAtTickEnd) {
        LoadedConfig config = BallisticsConfig.get();
        if (!config.enabled() || projectile.isRemoved() || hit == null) {
            return false;
        }
        if (hit.getType() != HitResult.Type.BLOCK || hit.isWorldBorderHit()) {
            return false;
        }
        // Déjà traité pendant ce tick : on annule le plantage sans recompter.
        if (PendingDeflect.has(projectile)) {
            return true;
        }

        BlockPos pos = hit.getBlockPos();
        BlockState state = projectile.level().getBlockState(pos);
        ResolvedSurface surface = SurfaceClassifier.classify(state, projectile.level(), pos, config);
        if (surface.behavior() == SurfaceBehavior.STICK) {
            return false;
        }

        BallisticMemory memory = projectile.getAttachedOrCreate(BallisticAttachments.MEMORY);
        long gameTime = projectile.level().getGameTime();
        boolean sameBlock = memory.hasLastBlock() && memory.lastBlockPos() == pos.asLong();
        long since = gameTime - memory.lastBounceGameTime();
        // Même tick seulement. Une fenêtre plus longue empêcherait un ricochet
        // de resauter sur la même surface d'eau au tick suivant.
        boolean repeated = sameBlock && since <= 0;

        ProjectileTraits traits = ProjectileTraits.of(projectile);
        DeflectSolution solution = BounceMath.solve(
                projectile.getDeltaMovement(),
                hit.getLocation(),
                BounceMath.outwardNormal(hit.getDirection()),
                surface,
                memory.bounces(),
                traits.bounceCap(),
                repeated,
                config
        );
        if (!solution.apply()) {
            return false;
        }

        projectile.setDeltaMovement(solution.velocity());
        projectile.setPos(solution.position());
        projectile.syncVelocity = true;
        projectile.needsSync = true;
        memory.rememberBlock(gameTime, pos.asLong(), solution.countBounce());
        if (solution.countBounce() && traits.scaleArrowDamage() && projectile instanceof AbstractArrowAccessor arrow) {
            scaleArrowDamage(projectile, arrow, memory, solution.damageMultiplier(), config);
        }
        projectile.setAttached(BallisticAttachments.MEMORY, memory);
        if (reassertAtTickEnd) {
            PendingDeflect.store(projectile, solution.velocity(), solution.position());
        }
        ImpactFeedback.emit(projectile, state, hit.getLocation(), solution.behavior(), solution.tone());
        return true;
    }

    /**
     * Appelé en fin de tick pour reprendre la main si vanilla a réécrit la vitesse
     * après {@code onHitBlock}.
     */
    public static boolean reassert(Projectile projectile) {
        return PendingDeflect.reassert(projectile);
    }

    /**
     * Évite un second dégât sur la même entité quand le rayon de fin de tick
     * retouche la cible dans la foulée du rebond. Un vrai tir de bande, plus loin
     * ou quelques ticks plus tard, passe.
     */
    public static boolean shouldSuppressEntityHit(Projectile projectile, Entity target) {
        LoadedConfig config = BallisticsConfig.get();
        BallisticMemory memory = projectile.getAttached(BallisticAttachments.MEMORY);
        if (!config.enabled() || memory == null || memory.bounces() <= 0 || !memory.hasLastHurt()) {
            return false;
        }
        if (memory.lastHurtEntityId() != target.getId()) {
            return false;
        }
        long since = projectile.level().getGameTime() - memory.lastHurtGameTime();
        if (since >= config.sameEntityImmunityTicks()) {
            return false;
        }
        double distance = projectile.position().distanceTo(new Vec3(memory.anchorX(), memory.anchorY(), memory.anchorZ()));
        return distance < config.sameEntityRearmDistance();
    }

    public static void rememberEntityHit(Projectile projectile, Entity target) {
        if (BallisticsConfig.get().enabled()) {
            BallisticMemory memory = projectile.getAttachedOrCreate(BallisticAttachments.MEMORY);
            Vec3 at = projectile.position();
            memory.rememberHurt(target.getId(), projectile.level().getGameTime(), at.x, at.y, at.z);
            projectile.setAttached(BallisticAttachments.MEMORY, memory);
        }
    }

    private static void scaleArrowDamage(
            Projectile projectile,
            AbstractArrowAccessor arrow,
            BallisticMemory memory,
            double multiplier,
            LoadedConfig config
    ) {
        if (projectile.level().isClientSide() || multiplier == 1.0) {
            return;
        }
        double current = arrow.materialballistics$getBaseDamage();
        if (!memory.hasOriginalDamage()) {
            memory.setOriginalDamage(current);
        }
        double capped = Math.min(memory.originalDamage() * config.damageCap(), current * multiplier);
        arrow.materialballistics$setBaseDamage(Math.max(0.0, capped));
    }
}
