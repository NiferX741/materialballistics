# Material Ballistics

Ricochets des projectiles selon le bloc touché.  
Minecraft **26.3**, Fabric Loader **≥ 0.20.1**, Fabric API, Java **25**.

Le JAR jouable est `build/libs/materialballistics-1.0.0.jar`.

## Ce que le mod change

Les flèches, flèches spectrales et tridents ne se plantent plus automatiquement.

| Surface | Comportement |
| --- | --- |
| Pierre, métal, obsidienne, verre | Rebond. La vitesse qui repart de la face est réduite, celle qui longe la face aussi. |
| Bois, terre, feuilles, laine, sable | Arrêt. La flèche se plante comme en vanilla. |
| Glace, neige | Glisse. Un impact rasant longe la face sans consommer un rebond. Un impact franc rebondit, avec un petit quota. |
| Eau, lave et autres fluides | Ricochet sur la surface. Un tir rasant rebondit loin, un tir vertical rebondit plus court. Après le quota, le projectile entre dans le fluide. |

La normale utilisée est la **face** du bloc (`Direction`), pas la pente visuelle d’un escalier ou d’une dalle.

Formule, avec une normale qui pointe hors du bloc :

```
v = vTangentiel + vNormal
vSortant = vTangentiel * friction - vNormal * restitution
```

`restitution` et `friction` sont plafonnées (0,95 et 1). Un rebond ne gagne pas de vitesse.

Les dégâts de flèche, eux, bougent :

- impact de face : × `headOnDamageMultiplier` (0,78)
- angle intermédiaire, autour de `sweetSpotAlignment` (0,45) : jusqu’à × `sweetSpotDamageMultiplier` (1,06)
- jamais au-dessus de `damageCap` × les dégâts du tir d’origine (1,08)

Le critique de l’arc est retiré au rebond. Le bonus d’angle le remplace.

## Installation

1. Instance Fabric 26.3 avec Fabric API.
2. Copier `materialballistics-1.0.0.jar` dans `mods`.
3. Lancer une fois. Le fichier `config/materialballistics.json` est créé.
4. Modifier la config ou les tags, puis **relancer le jeu**. La config n’est lue qu’au démarrage du serveur (et du client intégré).

Sur l’instance CurseForge « test 2 » :

`C:\Users\nifer\curseforge\minecraft\Instances\test 2\config\materialballistics.json`

Un JSON illisible est ignoré. Le jeu repart sur les valeurs internes et écrit l’erreur dans `logs/latest.log`.

## Config

```json
{
  "enabled": true,
  "minSpeed": 0.12,
  "separation": 0.06,
  "skimAlignment": 0.25,
  "sweetSpotAlignment": 0.45,
  "headOnDamageMultiplier": 0.78,
  "sweetSpotDamageMultiplier": 1.06,
  "damageCap": 1.08,
  "sameEntityImmunityTicks": 2,
  "sameEntityRearmDistance": 0.75,
  "slowRepeatWindow": 8,
  "glassRestitution": 0.55,
  "glassFriction": 0.7,
  "fallbackHardness": 1.5,
  "fallbackSlowKeep": 0.45,
  "fallbackRestitution": 0.72,
  "fallbackFriction": 0.84,
  "fallbackMaxBounces": 2,
  "rules": []
}
```

| Clé | Rôle |
| --- | --- |
| `enabled` | `false` remet le plantage vanilla. |
| `minSpeed` | En dessous de cette vitesse (blocs/tick), la flèche se plante. |
| `separation` | Décalage hors du bloc après l’impact, pour ne pas retoucher la même face dans la foulée. Borné de 0,01 à 0,25. |
| `skimAlignment` | Sur une surface `slide`, en dessous de cet alignement avec la normale l’impact est une glisse et ne compte pas comme rebond. 0 = rasant, 1 = de face. |
| `sweetSpotAlignment` | Alignement où le bonus de dégâts est maximal. |
| `headOnDamageMultiplier` | Multiplicateur de dégâts sur un impact de face. |
| `sweetSpotDamageMultiplier` | Multiplicateur au meilleur angle. |
| `damageCap` | Plafond par rapport aux dégâts du premier tir. |
| `sameEntityImmunityTicks` | Après un rebond, la même entité ne reprend pas de dégâts pendant ce nombre de ticks si la flèche est encore trop près. |
| `sameEntityRearmDistance` | Distance (blocs) au-delà de laquelle la même entité peut être touchée à nouveau, même dans la fenêtre de ticks. |
| `slowRepeatWindow` | Ticks pendant lesquels un même fluide ne réapplique pas le ralentissement. |
| `glassRestitution` / `glassFriction` | Verre qui n’est dans aucun tag. |
| `fallbackHardness` | Dureté à partir de laquelle un bloc hors tag rebondit, s’il n’a pas un son « tendre ». |
| `fallbackSlowKeep` | Part de vitesse conservée dans un fluide hors tag. |
| `fallbackRestitution` / `fallbackFriction` / `fallbackMaxBounces` | Rebond des blocs hors tag (son de pierre, de métal, ou dureté suffisante). |

Les valeurs hors bornes sont ramenées au chargement. `maxBounces` d’une règle est limité à 8. Une restitution de règle est limitée à 0,95.

### Règles

La **première** règle dont le tag contient le bloc gagne. L’ordre du tableau est donc la priorité. Par défaut : tendre, glisse, fluide, dur.

```json
{
  "tag": "materialballistics:ricochet/hard",
  "behavior": "ricochet",
  "restitution": 0.72,
  "friction": 0.84,
  "maxBounces": 2,
  "tone": "mineral"
}
```

`behavior` :

| Valeur | Alias | Effet |
| --- | --- | --- |
| `ricochet` | `bounce`, `rebond` | Réflexion. Chaque impact franc consomme un rebond. |
| `slide` | `glisse` | Rasant = glisse sans quota. Franc = rebond, avec `maxBounces`. |
| `slow` | `fluid`, `ralentir` | Ricochet sur un fluide. Rasant = rebond plat et rapide. Vertical = rebond plus mou. Hors quota, le projectile entre dans le fluide. |
| `stick` | tout le reste | Plantage vanilla. `restitution` et `friction` sont ignorés. |

`friction` garde la vitesse le long de la face. `restitution` garde la vitesse qui repart de la face. Sur du `slow`, `friction` est la part de vitesse conservée.

`tone` ne change pas la physique. Il choisit le son (celui du bloc, avec une hauteur différente) et les particules.

| `tone` | Alias | Particules |
| --- | --- | --- |
| `mineral` | | Étincelles et éclats du bloc |
| `metal` | `metallique` | Étincelles, son plus aigu |
| `glass` | `verre` | Étincelles et éclats, son plus aigu |
| `dull` | `sourd` | Flocons |
| `wet` | `fluide` | Bulles |

Un tag inconnu ou mal écrit est ignoré, avec un avertissement dans le log. Les autres règles restent actives.

Le nombre de rebonds effectif est le plus petit entre `maxBounces` de la surface et le plafond du projectile. Les flèches n’ont pas de plafond propre : la surface décide. Après le quota, la flèche se plante.

## Tags

Fichiers du mod, fusionnés avec les datapacks (`replace` est à `false`) :

| Tag | Id |
| --- | --- |
| Tendre, plantage | `materialballistics:ricochet/soft` |
| Glace et neige | `materialballistics:ricochet/slide` |
| Fluides | `materialballistics:ricochet/slow` |
| Dur, rebond | `materialballistics:ricochet/hard` |

Pour ajouter un bloc sans recompiler, un datapack suffit :

`data/materialballistics/tags/block/ricochet/hard.json`

```json
{
  "replace": false,
  "values": ["monmod:bloc_dur"]
}
```

`replace: true` remplace toute la liste du mod au lieu de la compléter.

### Blocs déjà classés

**Dur.** `#minecraft:base_stone_overworld`, `#minecraft:base_stone_nether`, `#minecraft:anvil`, `#minecraft:beacon_base_blocks`, obsidienne, obsidienne qui pleure, bedrock, deepslate renforcé, pierre de l’End, bloc de netherite, bloc de cuivre, pierres taillées, cobblestone, blackstone.

**Tendre.** Bûches, planches, feuilles, laine, terre, sable, argile, boue, mousse, botte de foin.

**Glisse.** `#minecraft:ice`, neige, bloc de neige, neige poudreuse.

**Fluide.** Eau, colonne de bulles, lave. Les flèches testent la surface avant de traverser. Un fluide hors tag (fluide de mod) ricoche aussi, avec `fluidRestitution` (0,62), `fluidFriction` (0,90) et `fluidMaxBounces` (5). `fluidSeparation` (0,32) sort la flèche de la surface pour que sa hitbox ne reste pas dans le liquide.

### Blocs hors tag

1. Fluide sans forme de collision : ralentissement.
2. Son de neige, de neige poudreuse ou de sable des âmes : glisse.
3. Son de bois, d’herbe, de sable, de gravier, de laine, de boue, de terre racineuse, de mousse ou d’herbe mouillée : plantage. Le bois a une dureté supérieure à 1,5, il est testé avant le seuil « dur ».
4. Son de verre : rebond avec `glassRestitution` / `glassFriction`.
5. Son de pierre, deepslate, tuf, calcite, améthyste, basalte, netherrack, dripstone, métal, fer, enclume, cuivre ou netherite, ou dureté négative (indestructible), ou dureté ≥ `fallbackHardness` : rebond avec les valeurs `fallback*`.
6. Sinon : plantage.

Le slime et le miel ne sont pas des cas spéciaux. Pour les faire rebondir, ajoute-les au tag `hard` ou à une règle placée avant `soft`.

## Garde-fous

- Vitesse déjà dirigée hors du bloc : pas d’inversion, plantage vanilla.
- Vitesse sous `minSpeed` : plantage.
- Deuxième impact sur le même bloc dans le même tick : la vitesse déjà calculée est conservée, sans rebond en plus.
- Même fluide revu dans `slowRepeatWindow` ticks : pas de second ralentissement.
- Fin du tick de la flèche : la vitesse est réécrite, parce que le jeu peut la remplacer juste après l’impact.
- Même entité, flèche encore dans `sameEntityRearmDistance`, et moins de `sameEntityImmunityTicks` écoulés depuis le coup précédent : le second dégât est ignoré. Un tir de bande qui a voyagé assez loin touche à nouveau. Le premier coup, avant tout rebond, n’est jamais filtré.

## Ce qui n’est pas branché

Branché : `Arrow`, `SpectralArrow`, `ThrownTrident`, et toute sous-classe de `AbstractArrow` qui ne réécrit pas `onHitBlock` sans appeler `super`.

Pas branché :

- boule de neige, œuf, potion, perle, bouteille d’expérience : leur `onHit` détruit l’entité après le choc
- boule de feu, charge de vent, balle de shulker : l’impact a déjà un effet propre

## Brancher un projectile custom

Au début de `onHitBlock`, avant le plantage ou le `discard()` :

```java
@Override
protected void onHitBlock(BlockHitResult hit) {
    if (RicochetController.tryDeflect(this, hit)) {
        return;
    }
    super.onHitBlock(hit);
}
```

`tryDeflect` renvoie `true` quand le plantage vanilla doit être annulé. La vitesse, la position et le quota sont déjà mis à jour.

Plafond pour un objet lancé, une fois au démarrage du mod :

```java
ProjectileTraits.register(MON_PROJECTILE, ProjectileTraits.THROWN);
```

| Trait | Quota | Dégâts de flèche (`baseDamage`) |
| --- | --- | --- |
| `ARROW` | celui de la surface | oui |
| `THROWN` | 1 | non |
| `GENERIC` | 2, ou moins si la surface est plus basse | non |

Sans enregistrement, une sous-classe de `AbstractArrow` reçoit `ARROW`. Le reste reçoit `GENERIC`.

Pour une boule de neige ou un équivalent, le mixin doit viser `onHit` : si le `HitResult` est un bloc et que `tryDeflect` renvoie vrai, ne pas appeler `discard()`.

## Build

Ouvrir `material-ballistics` comme projet Gradle séparé, avec un JDK 25.

```
gradlew build
```

Le JAR est `build/libs/materialballistics-1.0.0.jar`. Le fichier `-sources` n’est pas à mettre dans `mods`.
