package com.niferx.materialballistics.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.niferx.materialballistics.MaterialBallistics;
import com.niferx.materialballistics.ballistics.SurfaceBehavior;
import com.niferx.materialballistics.ballistics.SurfaceTone;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Block;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * {@code config/materialballistics.json}. Les tags référencés vivent dans le datapack du mod
 * ({@code data/materialballistics/tags/block/ricochet/}). Ajouter un bloc à un tag ne demande pas de code.
 * La première règle qui contient le bloc gagne.
 */
public final class BallisticsConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static volatile LoadedConfig current = builtin();

    private BallisticsConfig() {
    }

    public static LoadedConfig get() {
        return current;
    }

    public static void load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("materialballistics.json");
        try {
            if (Files.notExists(path)) {
                Files.createDirectories(path.getParent());
                writeDefault(path);
            }
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
                FileModel model = GSON.fromJson(json, FileModel.class);
                if (model == null) {
                    model = new FileModel();
                }
                fillMissing(json, model);
                current = model.toLoaded();
            }
            MaterialBallistics.LOGGER.info("Config balistique chargée ({})", path.toAbsolutePath());
        } catch (Exception exception) {
            current = builtin();
            MaterialBallistics.LOGGER.error("Config balistique illisible, repli sur les valeurs internes", exception);
        }
    }

    private static void writeDefault(Path path) throws IOException {
        FileModel model = FileModel.defaults();
        try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            GSON.toJson(model, writer);
        }
    }

    /** Gson n'exécute pas les initialiseurs : une clé absente resterait à 0. */
    private static void fillMissing(JsonObject json, FileModel model) {
        FileModel defaults = FileModel.defaults();
        if (!json.has("enabled")) model.enabled = defaults.enabled;
        if (!json.has("minSpeed")) model.minSpeed = defaults.minSpeed;
        if (!json.has("separation")) model.separation = defaults.separation;
        if (!json.has("skimAlignment")) model.skimAlignment = defaults.skimAlignment;
        if (!json.has("sweetSpotAlignment")) model.sweetSpotAlignment = defaults.sweetSpotAlignment;
        if (!json.has("headOnDamageMultiplier")) model.headOnDamageMultiplier = defaults.headOnDamageMultiplier;
        if (!json.has("sweetSpotDamageMultiplier")) model.sweetSpotDamageMultiplier = defaults.sweetSpotDamageMultiplier;
        if (!json.has("damageCap")) model.damageCap = defaults.damageCap;
        if (!json.has("sameEntityImmunityTicks")) model.sameEntityImmunityTicks = defaults.sameEntityImmunityTicks;
        if (!json.has("sameEntityRearmDistance")) model.sameEntityRearmDistance = defaults.sameEntityRearmDistance;
        if (!json.has("slowRepeatWindow")) model.slowRepeatWindow = defaults.slowRepeatWindow;
        if (!json.has("glassRestitution")) model.glassRestitution = defaults.glassRestitution;
        if (!json.has("glassFriction")) model.glassFriction = defaults.glassFriction;
        if (!json.has("fallbackHardness")) model.fallbackHardness = defaults.fallbackHardness;
        if (!json.has("fallbackSlowKeep")) model.fallbackSlowKeep = defaults.fallbackSlowKeep;
        if (!json.has("fallbackRestitution")) model.fallbackRestitution = defaults.fallbackRestitution;
        if (!json.has("fallbackFriction")) model.fallbackFriction = defaults.fallbackFriction;
        if (!json.has("fallbackMaxBounces")) model.fallbackMaxBounces = defaults.fallbackMaxBounces;
        if (!json.has("fluidRestitution")) model.fluidRestitution = defaults.fluidRestitution;
        if (!json.has("fluidFriction")) model.fluidFriction = defaults.fluidFriction;
        if (!json.has("fluidMaxBounces")) model.fluidMaxBounces = defaults.fluidMaxBounces;
        if (!json.has("fluidSeparation")) model.fluidSeparation = defaults.fluidSeparation;
        if (!json.has("rules") || model.rules == null) model.rules = defaults.rules;
    }

    private static LoadedConfig builtin() {
        return FileModel.defaults().toLoaded();
    }

    private static final class FileModel {
        boolean enabled = true;
        double minSpeed = 0.12;
        double separation = 0.06;
        double skimAlignment = 0.25;
        double sweetSpotAlignment = 0.45;
        double headOnDamageMultiplier = 0.78;
        double sweetSpotDamageMultiplier = 1.06;
        double damageCap = 1.08;
        int sameEntityImmunityTicks = 2;
        double sameEntityRearmDistance = 0.75;
        int slowRepeatWindow = 8;
        double glassRestitution = 0.55;
        double glassFriction = 0.70;
        double fallbackHardness = 1.5;
        double fallbackSlowKeep = 0.45;
        double fallbackRestitution = 0.72;
        double fallbackFriction = 0.84;
        int fallbackMaxBounces = 2;
        double fluidRestitution = 0.62;
        double fluidFriction = 0.90;
        int fluidMaxBounces = 5;
        double fluidSeparation = 0.32;
        List<RuleModel> rules = new ArrayList<>();

        static FileModel defaults() {
            FileModel model = new FileModel();
            model.rules = List.of(
                    RuleModel.of("materialballistics:ricochet/soft", "stick", 0.0, 0.0, 0, "dull"),
                    RuleModel.of("materialballistics:ricochet/slide", "slide", 0.22, 0.94, 4, "dull"),
                    RuleModel.of("materialballistics:ricochet/slow", "slow", 0.62, 0.90, 5, "wet"),
                    RuleModel.of("materialballistics:ricochet/hard", "ricochet", 0.72, 0.84, 2, "mineral")
            );
            return model;
        }

        LoadedConfig toLoaded() {
            List<SurfaceRule> resolved = new ArrayList<>();
            if (rules != null) {
                for (RuleModel rule : rules) {
                    SurfaceRule surface = rule.resolve();
                    if (surface != null) {
                        resolved.add(surface);
                    }
                }
            }
            return new LoadedConfig(
                    enabled,
                    Math.max(0.0, minSpeed),
                    Mth.clamp(separation, 0.01, 0.25),
                    Mth.clamp(skimAlignment, 0.0, 1.0),
                    Mth.clamp(sweetSpotAlignment, 0.05, 0.95),
                    Mth.clamp(headOnDamageMultiplier, 0.05, 1.5),
                    Mth.clamp(sweetSpotDamageMultiplier, 0.05, 1.5),
                    Mth.clamp(damageCap, 0.05, 1.5),
                    Math.max(0, sameEntityImmunityTicks),
                    Math.max(0.0, sameEntityRearmDistance),
                    Math.max(0, slowRepeatWindow),
                    Mth.clamp(glassRestitution, 0.0, 0.95),
                    Mth.clamp(glassFriction, 0.0, 1.0),
                    Math.max(0.0, fallbackHardness),
                    Mth.clamp(fallbackSlowKeep, 0.05, 1.0),
                    Mth.clamp(fallbackRestitution, 0.0, 0.95),
                    Mth.clamp(fallbackFriction, 0.0, 1.0),
                    Mth.clamp(fallbackMaxBounces, 0, 8),
                    Mth.clamp(fluidRestitution, 0.0, 0.95),
                    Mth.clamp(fluidFriction, 0.0, 1.0),
                    Mth.clamp(fluidMaxBounces, 0, 8),
                    Mth.clamp(fluidSeparation, 0.1, 0.6),
                    List.copyOf(resolved)
            );
        }
    }

    private static final class RuleModel {
        String tag;
        String behavior;
        double restitution;
        double friction;
        int maxBounces;
        String tone;

        static RuleModel of(String tag, String behavior, double restitution, double friction, int maxBounces, String tone) {
            RuleModel model = new RuleModel();
            model.tag = tag;
            model.behavior = behavior;
            model.restitution = restitution;
            model.friction = friction;
            model.maxBounces = maxBounces;
            model.tone = tone;
            return model;
        }

        SurfaceRule resolve() {
            if (tag == null || tag.isBlank()) {
                return null;
            }
            Identifier id;
            try {
                int colon = tag.indexOf(':');
                String namespace = colon < 0 ? "minecraft" : tag.substring(0, colon);
                String path = colon < 0 ? tag : tag.substring(colon + 1);
                id = Identifier.fromNamespaceAndPath(namespace, path);
            } catch (RuntimeException exception) {
                MaterialBallistics.LOGGER.warn("Tag de surface ignoré : {}", tag);
                return null;
            }
            TagKey<Block> key = TagKey.create(Registries.BLOCK, id);
            SurfaceBehavior parsed = SurfaceBehavior.parse(behavior);
            SurfaceTone parsedTone = parseTone(tone, parsed);
            double resolvedRestitution = restitution;
            double resolvedFriction = friction;
            int resolvedBounces = maxBounces;
            // Ancienne règle « slow » : ralentissement sans rebond. On la promeut
            // au ricochet de fluide tant que l'utilisateur ne l'a pas réglée.
            if (parsed == SurfaceBehavior.SLOW && resolvedRestitution <= 0.0 && resolvedBounces == 0 && Math.abs(resolvedFriction - 0.45) < 0.001) {
                resolvedRestitution = 0.62;
                resolvedFriction = 0.90;
                resolvedBounces = 5;
            }
            return new SurfaceRule(
                    key,
                    parsed,
                    Mth.clamp(resolvedRestitution, 0.0, 0.95),
                    Mth.clamp(resolvedFriction, 0.0, 1.0),
                    Mth.clamp(resolvedBounces, 0, 8),
                    parsedTone
            );
        }

        private static SurfaceTone parseTone(String raw, SurfaceBehavior behavior) {
            if (raw != null) {
                return switch (raw.trim().toLowerCase(java.util.Locale.ROOT)) {
                    case "metal", "metallique" -> SurfaceTone.METAL;
                    case "glass", "verre" -> SurfaceTone.GLASS;
                    case "wet", "fluide" -> SurfaceTone.WET;
                    case "dull", "sourd" -> SurfaceTone.DULL;
                    case "mineral", "minéral" -> SurfaceTone.MINERAL;
                    default -> fallbackTone(behavior);
                };
            }
            return fallbackTone(behavior);
        }

        private static SurfaceTone fallbackTone(SurfaceBehavior behavior) {
            return switch (behavior) {
                case SLOW -> SurfaceTone.WET;
                case SLIDE, STICK -> SurfaceTone.DULL;
                case RICOCHET -> SurfaceTone.MINERAL;
            };
        }
    }
}
