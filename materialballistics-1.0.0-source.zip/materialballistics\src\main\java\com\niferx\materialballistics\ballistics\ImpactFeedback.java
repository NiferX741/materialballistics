package com.niferx.materialballistics.ballistics;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.Vec3;

/**
 * Son du bloc touché et particules. Uniquement côté serveur : {@code sendParticles}
 * et {@code Entity#playSound} sont déjà diffusés aux clients. Les jouer aussi
 * sur le client du lanceur les doublerait en solo.
 */
public final class ImpactFeedback {
    private ImpactFeedback() {
    }

    @SuppressWarnings("deprecation")
    public static void emit(Projectile projectile, BlockState state, Vec3 at, SurfaceBehavior behavior, SurfaceTone tone) {
        if (!(projectile.level() instanceof ServerLevel level)) {
            return;
        }
        if (tone == SurfaceTone.WET || behavior == SurfaceBehavior.SLOW) {
            var fluidType = state.getFluidState().getType();
            boolean lava = fluidType == Fluids.LAVA || fluidType == Fluids.FLOWING_LAVA;
            float pitch = (lava ? 0.8F : 1.05F) * (0.92F + projectile.getRandom().nextFloat() * 0.16F);
            projectile.playSound(lava ? SoundEvents.LAVA_POP : SoundEvents.GENERIC_SPLASH, 0.65F, pitch);
            var particle = lava ? ParticleTypes.LAVA : ParticleTypes.SPLASH;
            level.sendParticles(particle, at.x, at.y, at.z, lava ? 4 : 8, 0.12, 0.05, 0.12, 0.04);
            if (!lava) {
                level.sendParticles(ParticleTypes.BUBBLE, at.x, at.y, at.z, 4, 0.08, 0.02, 0.08, 0.01);
            }
            return;
        }
        SoundType sound = state.getSoundType();
        SoundEvent event = sound.getHitSound();
        float pitch = sound.getPitch() * pitchScale(tone) * (0.92F + projectile.getRandom().nextFloat() * 0.16F);
        projectile.playSound(event, Math.min(0.8F, 0.45F + sound.getVolume() * 0.25F), pitch);

        int sparks = switch (behavior) {
            case RICOCHET -> 5;
            case SLIDE -> 3;
            case SLOW -> 6;
            case STICK -> 0;
        };
        if (sparks == 0) {
            return;
        }
        var particle = switch (tone) {
            case WET -> ParticleTypes.BUBBLE;
            case DULL -> ParticleTypes.ITEM_SNOWBALL;
            case METAL, MINERAL, GLASS -> ParticleTypes.ELECTRIC_SPARK;
        };
        level.sendParticles(particle, at.x, at.y, at.z, sparks, 0.05, 0.05, 0.05, 0.02);
        if (tone == SurfaceTone.MINERAL || tone == SurfaceTone.GLASS) {
            level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state), at.x, at.y, at.z, 3, 0.08, 0.08, 0.08, 0.04);
        }
    }

    private static float pitchScale(SurfaceTone tone) {
        return switch (tone) {
            case METAL -> 1.35F;
            case GLASS -> 1.55F;
            case MINERAL -> 0.85F;
            case WET -> 1.15F;
            case DULL -> 0.75F;
        };
    }
}
