package com.niferx.materialballistics.ballistics;

import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Correction de fin de tick. {@code AbstractArrow#onHitBlock} et la suite de
 * {@code stepMoveAndHit} peuvent réécrire la vélocité après notre calcul. On la
 * réapplique au RETURN de {@code tick}, une seule fois.
 */
final class PendingDeflect {
    private static final Map<Projectile, PendingDeflect> PENDING = Collections.synchronizedMap(new WeakHashMap<>());

    private final Vec3 velocity;
    private final Vec3 position;

    private PendingDeflect(Vec3 velocity, Vec3 position) {
        this.velocity = velocity;
        this.position = position;
    }

    static boolean has(Projectile projectile) {
        return PENDING.containsKey(projectile);
    }

    static void store(Projectile projectile, Vec3 velocity, Vec3 position) {
        PENDING.put(projectile, new PendingDeflect(velocity, position));
    }

    static boolean reassert(Projectile projectile) {
        PendingDeflect pending = PENDING.remove(projectile);
        if (pending == null) {
            return false;
        }
        projectile.setDeltaMovement(pending.velocity);
        projectile.setPos(pending.position);
        projectile.syncVelocity = true;
        projectile.needsSync = true;
        return true;
    }
}
