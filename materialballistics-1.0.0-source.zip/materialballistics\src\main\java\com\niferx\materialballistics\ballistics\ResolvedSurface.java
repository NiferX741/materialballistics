package com.niferx.materialballistics.ballistics;

/**
 * Coefficients déjà tranchés pour un bloc. {@code normalRestitution} scale la composante
 * qui repart selon la normale, {@code tangentialFriction} scale la composante qui longe la face.
 * Les deux sont bornés dans {@link com.niferx.materialballistics.ballistics.BounceMath}.
 */
public record ResolvedSurface(
        SurfaceBehavior behavior,
        double normalRestitution,
        double tangentialFriction,
        int maxBounces,
        SurfaceTone tone
) {
    public static ResolvedSurface stick(SurfaceTone tone) {
        return new ResolvedSurface(SurfaceBehavior.STICK, 0.0, 0.0, 0, tone);
    }
}
