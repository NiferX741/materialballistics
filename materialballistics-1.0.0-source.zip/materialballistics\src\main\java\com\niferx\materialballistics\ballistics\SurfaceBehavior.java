package com.niferx.materialballistics.ballistics;

/**
 * Décision de surface, avant le calcul vectoriel.
 */
public enum SurfaceBehavior {
    /** Réflexion avec restitution. La vélocité sortante reste sous la vitesse incidente. */
    RICOCHET,
    /** Impact rasant : on retire la composante qui entre dans le bloc et on garde le glissement. */
    SLIDE,
    /** Fluide : la vitesse est réduite et poussée hors du volume, sans rebond. */
    SLOW,
    /** Le projectile s'arrête. Le mixin laisse alors le plantage vanilla s'exécuter. */
    STICK;

    public static SurfaceBehavior parse(String raw) {
        if (raw == null) {
            return STICK;
        }
        return switch (raw.trim().toLowerCase(java.util.Locale.ROOT)) {
            case "ricochet", "bounce", "rebond" -> RICOCHET;
            case "slide", "glisse" -> SLIDE;
            case "slow", "fluid", "ralentir" -> SLOW;
            default -> STICK;
        };
    }
}
