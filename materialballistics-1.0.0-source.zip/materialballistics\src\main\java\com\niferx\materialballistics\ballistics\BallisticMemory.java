package com.niferx.materialballistics.ballistics;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/**
 * Mémoire par projectile. Mutable : après chaque écriture, l'appelant repasse l'instance
 * à {@code setAttached} pour que Fabric synchronise le quota de rebonds au client.
 * Sans ça, le client ricoche encore alors que le serveur a déjà décidé de planter.
 */
public final class BallisticMemory {
    public static final Codec<BallisticMemory> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.optionalFieldOf("bounces", 0).forGetter(BallisticMemory::bounces),
            Codec.LONG.optionalFieldOf("last_bounce_game_time", Long.MIN_VALUE).forGetter(BallisticMemory::lastBounceGameTime),
            Codec.BOOL.optionalFieldOf("has_last_block", false).forGetter(BallisticMemory::hasLastBlock),
            Codec.LONG.optionalFieldOf("last_block_pos", 0L).forGetter(BallisticMemory::lastBlockPos),
            Codec.BOOL.optionalFieldOf("has_last_hurt", false).forGetter(BallisticMemory::hasLastHurt),
            Codec.INT.optionalFieldOf("last_hurt_entity_id", 0).forGetter(BallisticMemory::lastHurtEntityId),
            Codec.LONG.optionalFieldOf("last_hurt_game_time", Long.MIN_VALUE).forGetter(BallisticMemory::lastHurtGameTime),
            Codec.BOOL.optionalFieldOf("has_original_damage", false).forGetter(BallisticMemory::hasOriginalDamage),
            Codec.DOUBLE.optionalFieldOf("original_damage", 0.0).forGetter(BallisticMemory::originalDamage),
            Codec.DOUBLE.optionalFieldOf("anchor_x", 0.0).forGetter(BallisticMemory::anchorX),
            Codec.DOUBLE.optionalFieldOf("anchor_y", 0.0).forGetter(BallisticMemory::anchorY),
            Codec.DOUBLE.optionalFieldOf("anchor_z", 0.0).forGetter(BallisticMemory::anchorZ)
    ).apply(instance, BallisticMemory::new));

    public static final StreamCodec<RegistryFriendlyByteBuf, BallisticMemory> STREAM_CODEC = StreamCodec.of(
            BallisticMemory::encode,
            BallisticMemory::decode
    );

    private int bounces;
    private long lastBounceGameTime = Long.MIN_VALUE;
    private boolean hasLastBlock;
    private long lastBlockPos;
    private boolean hasLastHurt;
    private int lastHurtEntityId;
    private long lastHurtGameTime = Long.MIN_VALUE;
    private boolean hasOriginalDamage;
    private double originalDamage;
    private double anchorX;
    private double anchorY;
    private double anchorZ;

    public BallisticMemory() {
    }

    public BallisticMemory(
            int bounces,
            long lastBounceGameTime,
            boolean hasLastBlock,
            long lastBlockPos,
            boolean hasLastHurt,
            int lastHurtEntityId,
            long lastHurtGameTime,
            boolean hasOriginalDamage,
            double originalDamage,
            double anchorX,
            double anchorY,
            double anchorZ
    ) {
        this.bounces = bounces;
        this.lastBounceGameTime = lastBounceGameTime;
        this.hasLastBlock = hasLastBlock;
        this.lastBlockPos = lastBlockPos;
        this.hasLastHurt = hasLastHurt;
        this.lastHurtEntityId = lastHurtEntityId;
        this.lastHurtGameTime = lastHurtGameTime;
        this.hasOriginalDamage = hasOriginalDamage;
        this.originalDamage = originalDamage;
        this.anchorX = anchorX;
        this.anchorY = anchorY;
        this.anchorZ = anchorZ;
    }

    public int bounces() {
        return bounces;
    }

    public long lastBounceGameTime() {
        return lastBounceGameTime;
    }

    public boolean hasLastBlock() {
        return hasLastBlock;
    }

    public long lastBlockPos() {
        return lastBlockPos;
    }

    public boolean hasLastHurt() {
        return hasLastHurt;
    }

    public int lastHurtEntityId() {
        return lastHurtEntityId;
    }

    public long lastHurtGameTime() {
        return lastHurtGameTime;
    }

    public boolean hasOriginalDamage() {
        return hasOriginalDamage;
    }

    public double originalDamage() {
        return originalDamage;
    }

    public double anchorX() {
        return anchorX;
    }

    public double anchorY() {
        return anchorY;
    }

    public double anchorZ() {
        return anchorZ;
    }

    public void setOriginalDamage(double originalDamage) {
        this.hasOriginalDamage = true;
        this.originalDamage = originalDamage;
    }

    public void rememberBlock(long gameTime, long blockPos, boolean countBounce) {
        this.lastBounceGameTime = gameTime;
        this.hasLastBlock = true;
        this.lastBlockPos = blockPos;
        if (countBounce) {
            this.bounces++;
        }
    }

    public void rememberHurt(int entityId, long gameTime, double x, double y, double z) {
        this.hasLastHurt = true;
        this.lastHurtEntityId = entityId;
        this.lastHurtGameTime = gameTime;
        this.anchorX = x;
        this.anchorY = y;
        this.anchorZ = z;
    }

    private static void encode(RegistryFriendlyByteBuf buf, BallisticMemory memory) {
        ByteBufCodecs.VAR_INT.encode(buf, memory.bounces);
        ByteBufCodecs.VAR_LONG.encode(buf, memory.lastBounceGameTime);
        ByteBufCodecs.BOOL.encode(buf, memory.hasLastBlock);
        ByteBufCodecs.LONG.encode(buf, memory.lastBlockPos);
        ByteBufCodecs.BOOL.encode(buf, memory.hasLastHurt);
        ByteBufCodecs.VAR_INT.encode(buf, memory.lastHurtEntityId);
        ByteBufCodecs.VAR_LONG.encode(buf, memory.lastHurtGameTime);
        ByteBufCodecs.BOOL.encode(buf, memory.hasOriginalDamage);
        ByteBufCodecs.DOUBLE.encode(buf, memory.originalDamage);
        ByteBufCodecs.DOUBLE.encode(buf, memory.anchorX);
        ByteBufCodecs.DOUBLE.encode(buf, memory.anchorY);
        ByteBufCodecs.DOUBLE.encode(buf, memory.anchorZ);
    }

    private static BallisticMemory decode(RegistryFriendlyByteBuf buf) {
        return new BallisticMemory(
                ByteBufCodecs.VAR_INT.decode(buf),
                ByteBufCodecs.VAR_LONG.decode(buf),
                ByteBufCodecs.BOOL.decode(buf),
                ByteBufCodecs.LONG.decode(buf),
                ByteBufCodecs.BOOL.decode(buf),
                ByteBufCodecs.VAR_INT.decode(buf),
                ByteBufCodecs.VAR_LONG.decode(buf),
                ByteBufCodecs.BOOL.decode(buf),
                ByteBufCodecs.DOUBLE.decode(buf),
                ByteBufCodecs.DOUBLE.decode(buf),
                ByteBufCodecs.DOUBLE.decode(buf),
                ByteBufCodecs.DOUBLE.decode(buf)
        );
    }
}
