package com.niferx.materialballistics.ballistics;

import com.niferx.materialballistics.config.LoadedConfig;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * Réflexion d'une vitesse sur une normale unitaire sortante.
 * <p>
 * La normale fournie par {@code BlockHitResult#getDirection()} pointe hors du bloc
 * (la face touchée). Une vitesse qui arrive sur cette face a un produit scalaire négatif.
 * <pre>
 *   v = vTangentiel + vNormal
 *   vSortant = vTangentiel * friction - vNormal * restitution
 * </pre>
 * Exemple : v = (1, -1, 0), n = (0, 1, 0), restitution = 1, friction = 1 donne (1, 1, 0).
 * La restitution est plafonnée à 0,95 pour qu'un rebond ne gagne jamais d'énergie.
 */
public final class BounceMath {
    /** Au-delà, un projectile resterait collé à la face et retoucherait le même bloc. */
    private static final double MIN_EXIT_ALONG_NORMAL = 0.04;

    private BounceMath() {
    }

    public static Vec3 outwardNormal(net.minecraft.core.Direction face) {
        return new Vec3(face.getStepX(), face.getStepY(), face.getStepZ());
    }

    public static DeflectSolution solve(
            Vec3 velocity,
            Vec3 contact,
            Vec3 normal,
            ResolvedSurface surface,
            int bouncesSoFar,
            int bounceCap,
            boolean repeatedContact,
            LoadedConfig config
    ) {
        if (!velocity.isFinite() || !normal.isFinite()) {
            return DeflectSolution.stick();
        }
        double restitution = clampUnit(surface.normalRestitution(), 0.95);
        double friction = clampUnit(surface.tangentialFriction(), 1.0);
        double approach = velocity.dot(normal);
        double speed = velocity.length();

        // Déjà en train de quitter la face : ne pas inverser une vitesse sortante.
        if (approach >= -1.0E-4 || speed < 1.0E-4) {
            return DeflectSolution.stick();
        }
        if (speed < config.minSpeed()) {
            return DeflectSolution.stick();
        }

        Vec3 separated = contact.add(normal.scale(config.separation()));
        // Un second passage le même tick (ou un fluide déjà ralenti) ne doit pas
        // recompter un rebond ni réempiler le ralentissement.
        if (repeatedContact) {
            Vec3 exiting = velocity.dot(normal) < MIN_EXIT_ALONG_NORMAL
                    ? cancelInward(velocity, normal, approach).add(normal.scale(MIN_EXIT_ALONG_NORMAL))
                    : velocity;
            return new DeflectSolution(true, false, exiting, separated, 1.0, surface.behavior(), surface.tone());
        }

        return switch (surface.behavior()) {
            case STICK -> DeflectSolution.stick();
            case SLOW -> fluidRicochet(velocity, normal, approach, speed, bouncesSoFar, bounceCap, surface, contact, config);
            case SLIDE -> slide(velocity, normal, approach, speed, friction, restitution, bouncesSoFar, bounceCap, surface, separated, config);
            case RICOCHET -> ricochet(velocity, normal, approach, speed, friction, restitution, bouncesSoFar, bounceCap, surface, separated, config);
        };
    }

    /**
     * Surface d'un fluide. Un angle rasant garde la vitesse le long de la surface
     * et fait un ricochet plat. Un tir vertical rebondit quand même, mais rend
     * moins de vitesse. Hors quota, le projectile entre dans le fluide.
     */
    private static DeflectSolution fluidRicochet(
            Vec3 velocity,
            Vec3 normal,
            double approach,
            double speed,
            int bouncesSoFar,
            int bounceCap,
            ResolvedSurface surface,
            Vec3 contact,
            LoadedConfig config
    ) {
        int allowed = Math.min(surface.maxBounces(), bounceCap);
        if (bouncesSoFar >= allowed) {
            return DeflectSolution.stick();
        }
        double alignment = Math.abs(approach) / speed;
        double restitution = clampUnit(surface.normalRestitution() * Mth.lerp(alignment, 1.0, 0.5), 0.95);
        double friction = clampUnit(surface.tangentialFriction() * Mth.lerp(alignment, 1.0, 0.62), 1.0);
        Vec3 normalComponent = normal.scale(approach);
        Vec3 tangential = velocity.subtract(normalComponent);
        Vec3 outgoing = tangential.scale(friction).subtract(normalComponent.scale(restitution));
        outgoing = ensureExit(outgoing, normal);
        if (!outgoing.isFinite() || outgoing.length() < config.minSpeed()) {
            return DeflectSolution.stick();
        }
        Vec3 separated = contact.add(normal.scale(Math.max(config.separation(), config.fluidSeparation())));
        double sweet = 1.0 - Math.abs(alignment - config.sweetSpotAlignment()) / Math.max(0.05, config.sweetSpotAlignment());
        sweet = Mth.clamp(sweet, 0.0, 1.0);
        double damage = Mth.lerp(sweet, config.headOnDamageMultiplier(), config.sweetSpotDamageMultiplier());
        return new DeflectSolution(true, true, outgoing, separated, damage, SurfaceBehavior.SLOW, surface.tone());
    }

    private static DeflectSolution slide(
            Vec3 velocity,
            Vec3 normal,
            double approach,
            double speed,
            double friction,
            double restitution,
            int bouncesSoFar,
            int bounceCap,
            ResolvedSurface surface,
            Vec3 separated,
            LoadedConfig config
    ) {
        double alignment = Math.abs(approach) / speed;
        // Impact rasant : on reste sur le plan, sans consommer le quota de rebonds.
        if (alignment < config.skimAlignment()) {
            double skimKeep = Math.max(friction, 0.985);
            // Pas de poussée le long de la normale : le projectile doit longer la face,
            // le décalage de position suffit à sortir du bloc.
            Vec3 skimming = cancelInward(velocity, normal, approach).scale(skimKeep);
            if (skimming.length() < config.minSpeed()) {
                return DeflectSolution.stick();
            }
            return new DeflectSolution(true, false, skimming, separated, 1.0, SurfaceBehavior.SLIDE, surface.tone());
        }
        return ricochet(velocity, normal, approach, speed, friction, restitution, bouncesSoFar, bounceCap, surface, separated, config);
    }

    private static DeflectSolution ricochet(
            Vec3 velocity,
            Vec3 normal,
            double approach,
            double speed,
            double friction,
            double restitution,
            int bouncesSoFar,
            int bounceCap,
            ResolvedSurface surface,
            Vec3 separated,
            LoadedConfig config
    ) {
        int allowed = Math.min(surface.maxBounces(), bounceCap);
        if (bouncesSoFar >= allowed) {
            return DeflectSolution.stick();
        }
        Vec3 normalComponent = normal.scale(approach);
        Vec3 tangential = velocity.subtract(normalComponent);
        Vec3 outgoing = tangential.scale(friction).subtract(normalComponent.scale(restitution));
        outgoing = ensureExit(outgoing, normal);
        if (!outgoing.isFinite() || outgoing.length() < config.minSpeed()) {
            return DeflectSolution.stick();
        }
        // Le bonus d'angle ne réinjecte pas de vitesse : il ne touche que les dégâts,
        // et le contrôleur le plafonne à damageCap fois les dégâts d'origine.
        double alignment = Math.abs(approach) / speed;
        double sweet = 1.0 - Math.abs(alignment - config.sweetSpotAlignment()) / Math.max(0.05, config.sweetSpotAlignment());
        sweet = Mth.clamp(sweet, 0.0, 1.0);
        double damage = Mth.lerp(sweet, config.headOnDamageMultiplier(), config.sweetSpotDamageMultiplier());
        return new DeflectSolution(true, true, outgoing, separated, damage, surface.behavior(), surface.tone());
    }

    /** Retire la composante dirigée vers l'intérieur du bloc. */
    private static Vec3 cancelInward(Vec3 velocity, Vec3 normal, double approach) {
        return velocity.subtract(normal.scale(approach));
    }

    private static Vec3 ensureExit(Vec3 velocity, Vec3 normal) {
        if (velocity.dot(normal) < MIN_EXIT_ALONG_NORMAL) {
            return velocity.add(normal.scale(MIN_EXIT_ALONG_NORMAL));
        }
        return velocity;
    }

    private static double clampUnit(double value, double max) {
        if (Double.isNaN(value)) {
            return 0.0;
        }
        return Mth.clamp(value, 0.0, max);
    }
}
